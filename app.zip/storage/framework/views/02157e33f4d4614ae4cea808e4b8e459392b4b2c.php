<footer class="footer">
	<div class="container-fluid">
		<nav class="navbar navbar-expand-lg navbar-bgcolor ">
			<ul class="navbar-nav mr-auto">
				<li class="nav-item active">
					<a class="nav-link" href="javascript:;">Home
						<span class="sr-only">(current)</span>
					</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="javascript:;">Features</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="javascript:;">Pricing</a>
				</li>
			</ul>
		</nav>
	</div>
</footer>
<?php /**PATH C:\Users\ayushma.jain\OneDrive\Documents\Learning\Laravel\BlogManagement\resources\views/includes/admin/footer.blade.php ENDPATH**/ ?>