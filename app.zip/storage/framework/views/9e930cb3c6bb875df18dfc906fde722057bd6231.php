<html>
    <head>
		<?php echo $__env->make('includes.frontend.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body id="page-top">
		
		<div >
			<?php echo $__env->make('includes.frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<div class="content">
				<?php echo $__env->yieldContent('content'); ?>
			</div>
			<input type="hidden" name="hf_base_url" id="hf_base_url" value="<?php echo e(url('/')); ?>">
		   <?php echo $__env->make('includes.frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
		
    </body>
</html><?php /**PATH C:\Users\ayushma.jain\OneDrive\Documents\Learning\Laravel\BlogManagement\resources\views/layouts/frontend/master.blade.php ENDPATH**/ ?>