
<?php $__env->startSection('content'); ?>
<?php $privileges = (Session::has('priviliges')) ? (array)Session::get('priviliges') : array(); ?>

	<div class="row">
		<div class="col-10">
			<div class="card">
				<div class="header">
					<span id="suspendMsg" class="error_msg"></span><br/>
					<?php if(in_array("add user", $privileges['user'])): ?> 
						<h4 class="title">USER LIST <input type="button" value="ADD USER" class="btn btn-sm btn-dark addUserBtn f-right " action-type="add"/></h4>
					<?php endif; ?>
				</div>
				<div class="p-2">
					 <table class="table table-borderd text-center mb-0">
						<thead>
							<tr>
								<th>S.No</th>
								<th>Name</th>
								<th>Email</th>
								<th>Phone Number</th>
								<th>Action</th>
								<th>Active/Deactive</th>
							</tr>
						</thead>
						<tbody>
							<?php if(isset($user_list) && count($user_list) > 0): ?>
								<?php $i=1; ?>
								<?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<input type="hidden" value="<?php echo e(json_encode($user)); ?>" id="user_<?php echo e($user['id']); ?>"/>
									<td><?php echo e($i); ?></td>
									<td><?php echo e($user['name']); ?></td>
									<td><?php echo e($user['email']); ?></td>
									<td><?php if(!empty($user['mobile_number'])): ?><?php echo e($user['mobile_number']); ?><?php else: ?><?php echo e('_'); ?> <?php endif; ?></td>
									<td>
										<span>
											<?php if(in_array("edit user", $privileges['user'])): ?> 
												<i class="fas fa-pencil-alt editUserBtn c_pointer" action-type="edit" user-id="<?php echo e($user['id']); ?>" data-toggle="tooltip" title="EDIT" data-placement="left"></i>
											<?php endif; ?>
											<?php if(in_array("view user", $privileges['user'])): ?> 
												<i class="fas fa-eye editUserBtn c_pointer" action-type="view" user-id="<?php echo e($user['id']); ?>"  data-toggle="tooltip" title="VIEW" data-placement="bottom"></i>
											<?php endif; ?>
											<?php if(in_array("delete user", $privileges['user'])): ?> 
												<i class="fas fa-trash-alt deleteUser c_pointer" user-id="<?php echo e($user['id']); ?>"  data-toggle="tooltip" title="DELETE"  data-placement="right"></i>
											<?php endif; ?>
											
										</span>
									</td>
									<td>
										<?php if(in_array("edit user", $privileges['user'])): ?> 
											<span data-toggle="tooltip" title="SUSPEND" data-placement="right">
												<label class="switch">
													<input type="checkbox" class="suspendUser" user-id="<?php echo e($user['id']); ?>" <?php if($user['status'] =='Y'): ?><?php echo e('checked'); ?><?php endif; ?> />
													<span class="slider round"></span>
												</label>
											</span>
										<?php endif; ?>
									</td>
								</tr>
								<?php $i++; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php else: ?>
								<tr>
									<td colspan="6" class="text-left">
										<b>No data found....</b>
									</td>
								</tr>
							<?php endif; ?>
						</tbody>
					 </table>
				</div>
				<div class="footer"></div>
			</div>
		</div>
	</div>
	<!-- Add/Edit/View User Modal Popup -->
	<div id="ModalLoginForm" class="modal fade">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">ADD USER</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<form role="form" method="POST" action="">
						<input type="hidden" name="_token" id="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="userid" id="userid" value="">
						<span class="error_msg" id="errorMsg"></span><br/>
						<div class="row">
							<div class="form-group col-6">
								<label class="control-label">Full Name</label>
								<div>
									<input type="text" class="form-control input-lg checkInputBlank" name="name" id="name" value="">
								</div>
							</div>
							<div class="form-group col-6">
								<label class="control-label">Mobile Number</label>
								<div>
									<input type="text" class="form-control input-lg checkInputBlank allowNumericOnly" name="phoneNo" id="phoneNo" value="">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="form-group col-8">
								<label class="control-label">Username / E-Mail Address</label>
								<div>
									<input type="email" class="form-control input-lg checkInputBlank" name="email" id="email" value="">
								</div>
							</div>
							<div class="form-group col-4">
								<label class="control-label">User Role</label>
								<div>
									<select class="form-control checkInputBlank" name="user_role" id="user_role">
										<option value="">SELECT ROLE</option>
										<?php if(isset($user_role_list) && count($user_role_list)>0): ?>
											<?php $__currentLoopData = $user_role_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($role['id']); ?>"><?php echo e($role['role_name']); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php endif; ?>
									</select>
								</div>
							</div>
						</div>
						<div class="row passwordDiv">
							<div class="form-group col-6">
								<label class="control-label">Password</label>
								<div>
									<input type="password" class="form-control input-lg checkInputBlank" name="password" id="password">
								</div>
							</div>
							<div class="form-group col-6">
								<label class="control-label">Confirm Password</label>
								<div>
									<input type="password" class="form-control input-lg" name="password_confirmation" id="password_confirmation">
								</div>
							</div>
						</div>
						<!--<div class="row">
							<div class="col-6">
								<div class="form-group">
									<label class="control-label">Password</label>
									<div>
										<input type="password" class="form-control input-lg" name="password">
									</div>
								</div>
								<div class="form-group">
									<label class="control-label">Confirm Password</label>
									<div>
										<input type="password" class="form-control input-lg" name="password_confirmation">
									</div>
								</div>
							</div>
							<div class="col-6">
								<!--<div class="form-group">
									<label class="control-label">Gender</label>
									<div class="m-2 pb-1">
										<div class="custom-control custom-radio mb-3 d-inline">
											<input type="radio" class="custom-control-input" id="male" name="gender" value="male"  />
											<label class="custom-control-label" for="male">Male</label>
									
										</div>
										<div class="custom-control custom-radio mb-3  d-inline">
											<input type="radio" class="custom-control-input" id="female" name="gender" value="female" />
											<label class="custom-control-label" for="female">Female</label>
											
										</div>
									</div>
								</div>
								<div class="form-group">
									<label class="control-label">User Role</label>
									<div>
										<select class="form-control" name="user_role">
											<option value="admin">Admin</option>
										</select>
									</div>
								</div>
							</div>
						</div>-->
						<div class="form-group text-right">
							<div>
								<button type="button" class="btn btn-success saveBtnDiv" id="addNewUser"> Save </button>
								<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
							</div>
						</div>
					</form>
				</div>
			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div>	

	<!-- Delete User Confimation Modal popup -->
	<div id="confirmationModal" class="modal fade">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
			  
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<h5>Are you Sure Do you want to delete this user ?</h5>
				 </div>   
					
				<div class="modal-footer">		
					<div class="form-group text-right">
						<div>
							<button type="button" class="btn btn-success " id="delete_user" rel="">Yes</button>
							<button type="button" class="btn btn-danger" data-dismiss="modal">No</button>
						</div>
					</div>
					
				</div>
			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div>	
	
	<!-- Delete User Message Modal popup -->
	<div id="SuccessMsgModal" class="modal fade">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
			  
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<h5 class="text text-success" id="successMsg">SuccessFully Deleted</h5>
					 <h5 class="text text-danger" id="failedMsg">Failed</h5>
				 </div>   
					
				<div class="modal-footer">		
					<div class="form-group text-right">
						<div>
							<button type="button" class="btn btn-danger" onClick="window.location.reload();">Ok</button>
						</div>
					</div>
					
				</div>
			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div>		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ayushma.jain\OneDrive\Documents\Learning\Laravel\BlogManagement\resources\views/user.blade.php ENDPATH**/ ?>