

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ayushma.jain\OneDrive\Documents\Learning\Laravel\BlogManagement\resources\views/dashboard.blade.php ENDPATH**/ ?>