<html>
    <head>
		<?php echo $__env->make('includes.admin.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body>
		<?php if(Request::is('/')): ?>
			<div class="content">
				<?php echo $__env->yieldContent('content'); ?>
			</div>
	    <?php else: ?>
			
		<?php echo $__env->make('includes.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="main-panel">
			<?php echo $__env->make('includes.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<div class="content">
				<?php echo $__env->yieldContent('content'); ?>
			</div>
			<input type="hidden" name="hf_base_url" id="hf_base_url" value="<?php echo e(url('/')); ?>">
		   <?php echo $__env->make('includes.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
		<?php endif; ?>
    </body>
</html><?php /**PATH C:\Users\ayushma.jain\OneDrive\Documents\Learning\Laravel\BlogManagement\resources\views/layouts/admin/master.blade.php ENDPATH**/ ?>