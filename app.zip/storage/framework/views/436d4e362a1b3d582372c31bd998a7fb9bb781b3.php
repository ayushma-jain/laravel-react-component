
<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-7">
			<div class="card "> 
				<div class="card-header">
					<b>My Profile</b>
				</div>
				<div class="card-body">
					<form role="form" method="POST" action="">
						<input type="hidden" name="_token" id="_token" value="<?php echo e(csrf_token()); ?>"/>
						<input type="hidden" name="userid" id="userid" value="<?php if(isset($user_data['id'])): ?><?php echo e($user_data['id']); ?> <?php endif; ?>"/>
						<input type="hidden"  name="user_role" id="user_role" value="<?php echo e($user_data['role_id']); ?>"/>
						<span class="error_msg" id="errorMsg"></span><br/>
						<div class="row">
							<div class="form-group col-6">
								<label class="control-label">Full Name</label>
								<div>
									<input type="text" class="form-control input-lg checkInputBlank" name="name" id="name" value="<?php if(isset($user_data['name'])): ?><?php echo e($user_data['name']); ?> <?php endif; ?>">
								</div>
							</div>
							<div class="form-group col-6">
								<label class="control-label">Mobile Number</label>
								<div>
									<input type="text" class="form-control input-lg checkInputBlank allowNumericOnly" name="phoneNo" id="phoneNo" value="<?php if(isset($user_data['mobile_number'])): ?><?php echo e($user_data['mobile_number']); ?> <?php endif; ?>">
								</div>
							</div>
							
						</div>
						<div class="row">
							<div class="form-group col-12">
								<label class="control-label">Username / E-Mail Address</label>
								<div>
									<input type="email" class="form-control input-lg checkInputBlank" name="email" id="email" value="<?php if(isset($user_data['email'])): ?><?php echo e($user_data['email']); ?> <?php endif; ?>">
								</div>
							</div>
						</div>
						<div class="row passwordDiv">
							<div class="form-group col-6">
								<label class="control-label">Password</label>
								<div>
									<input type="password" class="form-control input-lg checkInputBlank" name="password" id="password">
								</div>
							</div>
							<div class="form-group col-6">
								<label class="control-label">Confirm Password</label>
								<div>
									<input type="password" class="form-control input-lg" name="password_confirmation" id="password_confirmation">
								</div>
							</div>
						</div>
						<div class="form-group text-right">
							<div>
								<button type="button" class="btn btn-success " id="addNewUser"> Save </button>
							</div>
						</div>
					</form>
				</div>
				<div class="card-footer">
				</div>
			</div>
		</div>
		<div class="col-4">
			<div class="card">
				<div class="card-header">
					<b>My Privileges</b>
				</div>
				<div class="card-body">
					<h5 class="pt-2"> <b > Role : <?php if(isset($user_data['role_name'])): ?><?php echo e($user_data['role_name']); ?> <?php endif; ?></b></h5>
					
						<?php if(isset($user_data['priviliges'])): ?>
							<?php  $priviliges = json_decode($user_data['priviliges']); ?>
						
							<?php if(isset($priviliges) && !empty($priviliges)): ?>
								<?php $__currentLoopData = $priviliges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<h6 ><b style="text-transform: uppercase;"><?php echo e($key); ?> </b></h6>
									<ul>
										<?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li style="text-transform: uppercase;"><?php echo e($data); ?></li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</ul>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
						<?php endif; ?>
					
				</div>
				<div class="card-footer">
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ayushma.jain\OneDrive\Documents\Learning\Laravel\BlogManagement\resources\views/profile.blade.php ENDPATH**/ ?>