<footer class="footer">
	<div class="container-fluid">
		<nav class="navbar navbar-expand-lg navbar-bgcolor ">
			<ul class="navbar-nav mr-auto">
				<li class="nav-item active">
					<a class="nav-link" href="javascript:;">Home
						<span class="sr-only">(current)</span>
					</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="javascript:;">Features</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="javascript:;">Pricing</a>
				</li>
			</ul>
		</nav>
	</div>
</footer>
